
# Polimorfismo en Python
class Ave:
    def volar(self):
        return "El ave vuela"

class Pinguino(Ave):
    def volar(self):
        return "El pingüino no puede volar"

def hacer_volar(ave):
    print(ave.volar())

if __name__ == "__main__":
    hacer_volar(Ave())
    hacer_volar(Pinguino())
