
# Herencia en Python
class Animal:
    def sonido(self):
        return "Sonido genérico"

class Perro(Animal):
    def sonido(self):
        return "Guau"

if __name__ == "__main__":
    p = Perro()
    print(p.sonido())
