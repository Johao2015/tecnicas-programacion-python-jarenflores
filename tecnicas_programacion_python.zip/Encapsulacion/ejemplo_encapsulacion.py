
# Encapsulación en Python
class CuentaBancaria:
    def __init__(self, saldo):
        self.__saldo = saldo  # atributo privado

    def depositar(self, monto):
        self.__saldo += monto

    def obtener_saldo(self):
        return self.__saldo

if __name__ == "__main__":
    cuenta = CuentaBancaria(100)
    cuenta.depositar(50)
    print("Saldo:", cuenta.obtener_saldo())
